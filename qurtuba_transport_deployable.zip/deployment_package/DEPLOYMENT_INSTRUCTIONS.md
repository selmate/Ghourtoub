# تعليمات نشر تطبيق شركة قرطبة للنقل

هذا الملف يحتوي على تعليمات مفصلة لنشر تطبيق شركة قرطبة للنقل على مختلف منصات الاستضافة المجانية. اتبع الخطوات المناسبة للمنصة التي تختارها.

## المحتويات
1. [النشر على GitHub Pages](#النشر-على-github-pages)
2. [النشر على Netlify](#النشر-على-netlify)
3. [النشر على Vercel](#النشر-على-vercel)
4. [استخدام خادم ويب محلي](#استخدام-خادم-ويب-محلي)

## النشر على GitHub Pages

### المتطلبات المسبقة
- حساب على GitHub
- تثبيت Git على جهازك

### خطوات النشر
1. قم بإنشاء مستودع جديد على GitHub
   - انتقل إلى https://github.com/new
   - أدخل اسم المستودع (مثال: qurtuba-transport)
   - اختر "Public" لجعل المستودع عامًا
   - انقر على "Create repository"

2. قم بتهيئة Git في المجلد المحلي وربطه بالمستودع
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/qurtuba-transport.git
   git push -u origin master
   ```

3. قم بتفعيل GitHub Pages
   - انتقل إلى إعدادات المستودع على GitHub
   - انتقل إلى قسم "Pages"
   - اختر الفرع "master" والمجلد "/ (root)"
   - انقر على "Save"

4. انتظر بضع دقائق حتى يتم نشر الموقع
   - ستظهر رسالة تحتوي على رابط الموقع المنشور (مثال: https://YOUR_USERNAME.github.io/qurtuba-transport)

## النشر على Netlify

### المتطلبات المسبقة
- حساب على Netlify

### خطوات النشر
1. قم بإنشاء حساب أو تسجيل الدخول على Netlify
   - انتقل إلى https://app.netlify.com/signup

2. انقر على "New site from upload"
   - اختر "Deploy manually"
   - اسحب وأفلت مجلد التطبيق بأكمله إلى المنطقة المخصصة

3. انتظر حتى تكتمل عملية النشر
   - ستحصل على رابط عشوائي للموقع (مثال: https://random-name-123456.netlify.app)

4. يمكنك تخصيص اسم النطاق الفرعي
   - انتقل إلى إعدادات الموقع
   - اختر "Domain settings"
   - انقر على "Options" بجانب النطاق الفرعي
   - اختر "Edit site name"

## النشر على Vercel

### المتطلبات المسبقة
- حساب على Vercel

### خطوات النشر
1. قم بإنشاء حساب أو تسجيل الدخول على Vercel
   - انتقل إلى https://vercel.com/signup

2. انقر على "New Project"
   - اختر "Upload" من القائمة
   - اسحب وأفلت مجلد التطبيق بأكمله إلى المنطقة المخصصة

3. انتظر حتى تكتمل عملية النشر
   - ستحصل على رابط للموقع (مثال: https://qurtuba-transport.vercel.app)

## استخدام خادم ويب محلي

إذا كنت ترغب في تشغيل التطبيق محليًا على جهازك، يمكنك استخدام أي خادم ويب بسيط.

### باستخدام Node.js
1. قم بتثبيت Node.js من https://nodejs.org/
2. قم بتثبيت حزمة serve:
   ```bash
   npm install -g serve
   ```
3. انتقل إلى مجلد التطبيق وقم بتشغيل الخادم:
   ```bash
   serve -s .
   ```
4. افتح المتصفح وانتقل إلى http://localhost:5000

### باستخدام Python
1. قم بتثبيت Python من https://python.org/
2. انتقل إلى مجلد التطبيق وقم بتشغيل الخادم:
   ```bash
   # لـ Python 3
   python -m http.server
   # أو لـ Python 2
   python -m SimpleHTTPServer
   ```
3. افتح المتصفح وانتقل إلى http://localhost:8000

## ملاحظات هامة

- تأكد من أن جميع الملفات موجودة في المجلد قبل النشر
- إذا واجهت أي مشاكل في التوجيه (routing)، قد تحتاج إلى إضافة ملف _redirects (لـ Netlify) أو vercel.json (لـ Vercel) للتعامل مع توجيهات React Router
- للحصول على مساعدة إضافية، يمكنك التواصل معنا على البريد الإلكتروني: support@qurtuba-transport.com
